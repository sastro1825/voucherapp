<?php $__env->startSection('title', 'Redeemed Vouchers'); ?>

<?php $__env->startSection('sidebar-title'); ?>
    <div class="flex flex-col items-center mb-4">
        <img src="<?php echo e(asset('images/FT.png')); ?>" alt="Logo" class="h-12 w-auto mb-2">
        <span class="text-lg font-semibold text-gray-800 dark:text-gray-200">Merchant Panel</span>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <li>
        <a href="<?php echo e(route('merchant.dashboard')); ?>#redeem-voucher" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Redeem Voucher</a>
    </li>
    <li>
        <a href="<?php echo e(route('merchant.redeemed-vouchers')); ?>" class="block p-2 bg-gray-200 dark:bg-gray-700 rounded">View Redeemed Vouchers</a>
    </li>
    <li>
        <a href="<?php echo e(route('profile')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Profil</a>
    </li>
    <li>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block w-full text-left p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Logout</button>
        </form>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold mb-6">Redeemed Vouchers</h1>
    <div class="bg-white dark:bg-gray-800 p-6 rounded shadow">
        <style>
            .centered-table th,
            .centered-table td {
                text-align: center;
            }
        </style>
        <table class="w-full border-collapse centered-table">
            <thead>
                <tr class="bg-gray-200 dark:bg-gray-700">
                    <th class="p-2 border dark:border-gray-600">Voucher ID</th>
                    <th class="p-2 border dark:border-gray-600">Value</th>
                    <th class="p-2 border dark:border-gray-600">Redeemed At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $redeemed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b dark:border-gray-600">
                        <td class="p-2"><?php echo e($item->voucher->id); ?></td>
                        <td class="p-2"><?php echo e($item->voucher->value); ?></td>
                        <td class="p-2"><?php echo e(\Carbon\Carbon::parse($item->redeemed_at)->timezone('Asia/Jakarta')->format('Y-m-d H:i:s')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\project fibertrust fix\nafis1\voucher2\resources\views/merchant/redeemed.blade.php ENDPATH**/ ?>