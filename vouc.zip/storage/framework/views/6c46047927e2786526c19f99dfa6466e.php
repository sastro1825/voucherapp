<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('sidebar-title'); ?>
    <div class="flex flex-col items-center mb-4">
        <img src="<?php echo e(asset('images/FT.png')); ?>" alt="Logo" class="h-12 w-auto mb-2">
        <span class="text-lg font-semibold text-gray-800 dark:text-gray-200">Admin Panel</span>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <li>
        <a href="<?php echo e(route('admin.create-voucher')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Create Voucher</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create-merchant')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Create Merchant</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.vouchers')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">View All Vouchers</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.users')); ?>" class="block p-2 bg-gray-200 dark:bg-gray-700 rounded">View All Users</a>
    </li>
    <li x-data="{ showSetting: false }">
        <button @click="showSetting = !showSetting" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded w-full text-left flex justify-between items-center">
            Setting
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
            </svg>
        </button>
        <ul x-show="showSetting" class="pl-4">
            <li>
                <a href="<?php echo e(route('profile')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Profil</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.update-company')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Update Company Name</a>
            </li>
        </ul>
    </li>
    <li>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block w-full text-left p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Logout</button>
        </form>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 bg-white dark:bg-gray-800 p-6 rounded shadow">
        <h2 class="text-2xl font-bold mb-4">Edit User: <?php echo e($user->username); ?></h2>
        <?php if(session('success')): ?>
            <div class="text-green-500 mb-4"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="text-red-500 mb-4"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('admin.user.edit', $user->id)); ?>" onsubmit="return confirm('Apakah Anda yakin ingin memperbarui user ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <div class="mb-4">
                <label for="username" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Username</label>
                <input type="text" name="username" id="username" value="<?php echo e(old('username', $user->username)); ?>" class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                       placeholder="Username" required>
                <?php if($errors->has('username')): ?>
                    <span class="text-red-500 text-sm"><?php echo e($errors->first('username')); ?></span>
                <?php endif; ?>
            </div>
            <?php if($user->role === 'merchant'): ?>
                <div class="mb-4">
                    <label for="merchant_name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Merchant Name</label>
                    <input type="text" name="merchant_name" id="merchant_name" value="<?php echo e(old('merchant_name', $user->merchant_name)); ?>" 
                           class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                           placeholder="Merchant Name" required>
                    <?php if($errors->has('merchant_name')): ?>
                        <span class="text-red-500 text-sm"><?php echo e($errors->first('merchant_name')); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="mb-4">
                <label for="whatsapp_number" class="block text-sm font-medium text-gray-700 dark:text-gray-300">WhatsApp Number</label>
                <input type="text" name="whatsapp_number" id="whatsapp_number" value="<?php echo e(old('whatsapp_number', $user->whatsapp_number)); ?>" 
                       class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                       placeholder="WhatsApp Number (e.g., 6281234567890)" required>
                <?php if($errors->has('whatsapp_number')): ?>
                    <span class="text-red-500 text-sm"><?php echo e($errors->first('whatsapp_number')); ?></span>
                <?php endif; ?>
            </div>
            <div class="mb-4">
                <label for="information" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Information</label>
                <textarea name="information" id="information" class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                          placeholder="Additional information about the user"><?php echo e(old('information', $user->information)); ?></textarea>
                <?php if($errors->has('information')): ?>
                    <span class="text-red-500 text-sm"><?php echo e($errors->first('information')); ?></span>
                <?php endif; ?>
            </div>
            <?php if($user->role === 'merchant'): ?>
                <div class="mb-4">
                    <label for="remaining_balance" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Merchant Balance (Current Month)</label>
                    <input type="number" name="remaining_balance" id="remaining_balance" 
                           value="<?php echo e(old('remaining_balance', $balance ? $balance->remaining_balance : 300000)); ?>" 
                           class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                           placeholder="Enter remaining balance (0 - 300000)" min="0" max="300000" required>
                    <?php if($errors->has('remaining_balance')): ?>
                        <span class="text-red-500 text-sm"><?php echo e($errors->first('remaining_balance')); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="mb-4">
                <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300">New Password (optional)</label>
                <input type="password" name="password" id="password" class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                       placeholder="New Password">
                <?php if($errors->has('password')): ?>
                    <span class="text-red-500 text-sm"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
            <div class="mb-4">
                <label for="password_confirmation" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Confirm New Password</label>
                <input type="password" name="password_confirmation" id="password_confirmation" 
                       class="w-full p-2 border rounded mb-2 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                       placeholder="Confirm New Password">
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="text-red-500 text-sm"><?php echo e($errors->first('password_confirmation')); ?></span>
                <?php endif; ?>
            </div>
            <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
                Update User
            </button>
            <a href="<?php echo e(route('admin.users')); ?>" class="ml-4 bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-700">
                Cancel
            </a>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\nafis1\voucher2\resources\views/admin/edit-user.blade.php ENDPATH**/ ?>