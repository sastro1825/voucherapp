<?php $__env->startSection('title', 'All Users'); ?>

<?php $__env->startSection('sidebar-title'); ?>
    <div class="flex flex-col items-center mb-4">
        <img src="<?php echo e(asset('images/FT.png')); ?>" alt="Logo" class="h-12 w-auto mb-2">
        <span class="text-lg font-semibold text-gray-800 dark:text-gray-200">Admin Panel</span>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <li>
        <a href="<?php echo e(route('admin.create-voucher')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Create Voucher</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create-merchant')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Create Merchant</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.vouchers')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">View All Vouchers</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.users')); ?>" class="block p-2 bg-gray-200 dark:bg-gray-700 rounded">View All Users</a>
    </li>
    <li x-data="{ showSetting: false }">
        <button @click="showSetting = !showSetting" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded w-full text-left flex justify-between items-center">
            Setting
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
            </svg>
        </button>
        <ul x-show="showSetting" class="pl-4">
            <li>
                <a href="<?php echo e(route('profile')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Profil</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.update-company')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Update Company Name</a>
            </li>
        </ul>
    </li>
    <li>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block w-full text-left p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Logout</button>
        </form>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold mb-6">All Users</h1>

    <!-- Notification -->
    <?php if(session('success')): ?>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <?php endif; ?>

    <!-- Search Form -->
    <div class="mb-6">
        <form action="<?php echo e(route('admin.users')); ?>" method="GET" class="flex items-center space-x-3">
            <input type="text" name="search" value="<?php echo e($search ?? ''); ?>" placeholder="Search by username..." 
                   class="w-full max-w-md p-2 border rounded dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition duration-150 mr-2">
            <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-lg shadow-sm hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition duration-150">Search</button>
            <?php if($search): ?>
                <a href="<?php echo e(route('admin.users')); ?>" class="px-4 py-2 bg-red-600 text-white rounded-lg shadow-sm hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 transition duration-150">Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Table -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded shadow overflow-x-auto">
        <?php if($users->isEmpty()): ?>
            <p class="text-center text-gray-500 dark:text-gray-400">No users found.</p>
        <?php else: ?>
            <table class="w-full border-collapse text-sm">
                <thead>
                    <tr class="bg-gray-200 dark:bg-gray-700">
                        <th class="p-2 border dark:border-gray-600">Username</th>
                        <th class="p-2 border dark:border-gray-600">Merchant Name</th>
                        <th class="p-2 border dark:border-gray-600">Nomor WA</th>
                        <th class="p-2 border dark:border-gray-600">Role</th>
                        <th class="p-2 border dark:border-gray-600">Information</th>
                        <th class="p-2 border dark:border-gray-600">Saldo Merchant</th>
                        <th class="p-2 border dark:border-gray-600">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b dark:border-gray-600">
                            <td class="p-2 text-center"><?php echo e($user->username); ?></td>
                            <td class="p-2 text-center"><?php echo e($user->merchant_name ?? '-'); ?></td>
                            <td class="p-2 text-center"><?php echo e($user->whatsapp_number ?? '-'); ?></td>
                            <td class="p-2 text-center"><?php echo e(ucfirst($user->role)); ?></td>
                            <td class="p-2 text-center"><?php echo e($user->information ?? '-'); ?></td>
                            <td class="p-2 text-center">
                                <?php if($user->role === 'merchant'): ?>
                                    <?php echo e($user->merchantBalances->first()->remaining_balance ?? 300000); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="p-2">
                                <div class="flex items-center justify-start space-x-2">
                                    <a href="<?php echo e(route('admin.user.edit', $user->id)); ?>" 
                                       class="ml-4 inline-flex items-center w-24 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg shadow-sm hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-150">
                                        <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15.828a2 2 0 01-2.828 0l-1.414-1.414a2 2 0 010-2.828z"></path>
                                        </svg>
                                        Edit
                                    </a>
                                    <?php if($user->role !== 'admin'): ?>
                                        <form action="<?php echo e(route('admin.user.delete', $user->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus user ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" 
                                                    class="inline-flex items-center w-24 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg shadow-sm hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 transition duration-150">
                                                <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5-4h4m-4 4v12m4-12v12"></path>
                                                </svg>
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if(session('success') || session('error')): ?>
        <script>
            setTimeout(function() {
                window.location.reload();
            }, 3000);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\project fibertrust fix\nafis1\voucher2\resources\views/admin/users.blade.php ENDPATH**/ ?>