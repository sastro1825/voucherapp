<?php $__env->startSection('title', 'Create Voucher'); ?>

<?php $__env->startSection('sidebar-title'); ?>
    <div class="flex flex-col items-center mb-4">
        <img src="<?php echo e(asset('images/FT.png')); ?>" alt="Logo" class="h-12 w-auto mb-2">
        <span class="text-lg font-semibold text-gray-800 dark:text-gray-200">Admin Panel</span>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <li>
        <a href="<?php echo e(route('admin.create-voucher')); ?>" class="block p-2 bg-gray-200 dark:bg-gray-700 rounded">Create Voucher</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create-merchant')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Create Merchant</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.vouchers')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">View All Vouchers</a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.users')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">View All Users</a>
    </li>
    <li x-data="{ showSetting: false }">
        <button @click="showSetting = !showSetting" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded w-full text-left flex justify-between items-center">
            Setting
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
            </svg>
        </button>
        <ul x-show="showSetting" class="pl-4">
            <li>
                <a href="<?php echo e(route('profile')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Profil</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.update-company')); ?>" class="block p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Update Company Name</a>
            </li>
        </ul>
    </li>
    <li>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block w-full text-left p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded">Logout</button>
        </form>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 bg-white dark:bg-gray-800 p-6 rounded shadow">
        <h2 class="text-2xl font-bold mb-4">Create Voucher</h2>
        <?php if(session('success')): ?>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('admin.create-voucher.submit')); ?>" onsubmit="return confirm('Apakah Anda yakin ingin membuat voucher ini?')">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="merchant_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Pilih Merchant</label>
                <select name="merchant_id" id="merchant_id" class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" required>
                    <option value="">-- Pilih Merchant --</option>
                    <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($merchant->id); ?>"><?php echo e($merchant->username); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['merchant_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="value" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nilai Voucher</label>
                <input type="number" name="value" id="value" class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-gray-100" 
                       placeholder="Voucher value" required>
                <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="mt-2 bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700">
                Create Voucher
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if(session('success') || session('error')): ?>
        <script>
            setTimeout(function() {
                window.location.reload();
            }, 3000);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\project fibertrust fix\nafis1\voucher2\resources\views/admin/create-voucher.blade.php ENDPATH**/ ?>